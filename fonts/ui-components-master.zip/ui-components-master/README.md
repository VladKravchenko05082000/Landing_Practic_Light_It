# UI Components
UI Components - это набор адаптивных компонентов с открытым исходным кодом для создания пользовательского интерфейса сайтов и веб-приложений.

Список компонентов:

- ChiefSlider
- CustomSelect
- Modal
- SimpleAdaptiveSlider
- Toast
